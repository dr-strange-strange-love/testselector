
from distutils.core import setup

setup(
	name='jobconstructor',
	version='1.0',
	packages=['jobconstructor',],
	license='GNU GENERAL PUBLIC LICENSE',
	long_description=open('README.txt').read(),
)
