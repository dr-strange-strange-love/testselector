
class JobConstructorException(Exception):
	pass
